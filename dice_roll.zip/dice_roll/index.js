let scores = [];
let rounds = 0;
const totalRounds = 6;

function initializeGame(numberOfPlayers) {
    scores = new Array(numberOfPlayers).fill(0);
    rounds = 0;
    //document.querySelector("h1").textContent = "Let's Play!";
    generatePlayerSections(numberOfPlayers);
}

function generatePlayerSections(numberOfPlayers) {
    const playersContainer = document.getElementById('players');
    playersContainer.innerHTML = ''; // Clear existing players
    for (let i = 1; i <= numberOfPlayers; i++) {
        const playerDiv = document.createElement('div');
        playerDiv.className = `player${i}`;
        playerDiv.innerHTML = `
            <button type="button" class="button${i}"> Player ${i} </button>
            <img class="img${i}" src="images/dice6.png" />
        `;
        playersContainer.appendChild(playerDiv);
    }
    addEventListeners(numberOfPlayers);
}

function rollDice(playerIndex) {
    let diceValue = Math.floor(Math.random() * 6) + 1;
    document.querySelector(`.img${playerIndex}`).setAttribute("src", `images/dice${diceValue}.png`);
    scores[playerIndex - 1] += diceValue;

    if (playerIndex === scores.length) {
        rounds++;
        if (rounds === totalRounds) {
            displayFinalWinner();
        } else {
            displayRoundWinner();
        }
    }
}

function displayRoundWinner() {
    let maxScore = Math.max(...scores);
    let winner = scores.indexOf(maxScore) + 1;
    alert(`Round ${rounds} winner : Player ${winner} with ${maxScore} points!`);
}

function displayFinalWinner() {
    let maxScore = Math.max(...scores);
    let winner = scores.indexOf(maxScore) + 1;
    alert(`Final winner : Player ${winner} with ${maxScore} points after ${totalRounds} rounds!`);
    resetGame();
}

function loadScreen() {
    document.querySelector("h1").textContent = "Let's Play!";
    for (let i = 1; i <= scores.length; i++) {
        document.querySelector(`.img${i}`).setAttribute("src", "images/dice6.png");
    }
    scores.fill(0);
    rounds = 0;
}

function resetGame() {
    loadScreen();
    scores = new Array(scores.length).fill(0);
    rounds = 0;
}

function addEventListeners(numberOfPlayers) {
    for (let i = 1; i <= numberOfPlayers; i++) {
        document.querySelector(`.button${i}`).addEventListener("click", () => rollDice(i));
    }
    document.querySelector(".Clear").addEventListener("click", loadScreen);
}

document.addEventListener("DOMContentLoaded", () => {
    const numberOfPlayers = document.querySelectorAll('[class^="player"]').length; // Determine number of players from HTML
    initializeGame(numberOfPlayers);
});
