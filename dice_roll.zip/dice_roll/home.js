function startGame() {
    const select = document.getElementById("playerSelect");
    const numberOfPlayers = select.value;
    if (numberOfPlayers === '2' || numberOfPlayers === '3' || numberOfPlayers === '4') {
        window.location.assign(`dice_${numberOfPlayers}.html`);
    } else {
        alert("Please select a valid number of players.");
    }
}
